using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

public abstract class SequencedAreaAttackAbility : Ability
{
    [Header("Presentation")]
    [SerializeField] private string animationName = "Attack1";
    [SerializeField] private bool stopMovement = true;
    [SerializeField] private bool faceMousePosition = true;

    protected void ActivateSequence(GameObject parent, IReadOnlyList<AreaHitStep> hitSteps)
    {
        if (parent == null || hitSteps == null || hitSteps.Count == 0) return;

        PlayerActor playerActor = parent.GetComponent<PlayerActor>();
        if (playerActor == null) return;

        if (stopMovement && parent.TryGetComponent(out NavMeshAgent agent))
        {
            agent.ResetPath();
        }

        if (faceMousePosition)
        {
            FaceMousePosition(parent.transform);
        }

        if (!string.IsNullOrWhiteSpace(animationName) && parent.TryGetComponent(out Animator animator))
        {
            animator.Play(animationName, 0, 0f);
        }

        MonoBehaviour runner = parent.GetComponent<AbilityHolder>();
        if (runner != null)
        {
            runner.StartCoroutine(ApplyHitSteps(parent.transform, playerActor, hitSteps));
            return;
        }

        ApplyDueHitSteps(parent.transform, playerActor, hitSteps, float.PositiveInfinity);
    }

    private static IEnumerator ApplyHitSteps(Transform ownerTransform, PlayerActor playerActor, IReadOnlyList<AreaHitStep> hitSteps)
    {
        float elapsed = 0f;
        bool[] appliedSteps = new bool[hitSteps.Count];
        int appliedCount = 0;

        while (appliedCount < hitSteps.Count)
        {
            elapsed += Time.deltaTime;
            appliedCount += ApplyDueHitSteps(ownerTransform, playerActor, hitSteps, elapsed, appliedSteps);
            yield return null;
        }
    }

    private static int ApplyDueHitSteps(Transform ownerTransform, PlayerActor playerActor, IReadOnlyList<AreaHitStep> hitSteps, float elapsed, bool[] appliedSteps = null)
    {
        if (!ownerTransform || !playerActor) return 0;

        int appliedCount = 0;
        WeaponScript weapon = playerActor.CurrentWeapon;
        for (int i = 0; i < hitSteps.Count; i++)
        {
            if (appliedSteps != null && appliedSteps[i]) continue;

            AreaHitStep hitStep = hitSteps[i];
            if (hitStep == null || elapsed < hitStep.delay) continue;

            if (appliedSteps != null)
            {
                appliedSteps[i] = true;
            }

            ApplyHitStep(ownerTransform, playerActor, weapon, hitStep);
            appliedCount++;
        }

        return appliedCount;
    }

    /// <summary>
    /// Resolves one <see cref="AreaHitStep"/> through <see cref="PlayerActor.TryApplyAreaDamage"/> and
    /// returns the number of enemies that <em>effectively</em> took damage. Changing the former
    /// <c>void</c> return to <c>int</c> is non-breaking (existing callers simply ignore the value); the
    /// count is surfaced so <see cref="BreakerGauntletCombat"/> can feed <see cref="HitStop.ShouldApply"/>
    /// and apply a hit-stop exactly once per ImpactEvent, independent of how many enemies were hit
    /// (R7.1, R7.3). The damage channel itself is unchanged.
    /// </summary>
    /// <returns>The number of enemies the hit step resolved damage on (0 when it hit nothing).</returns>
    internal static int ApplyHitStep(Transform ownerTransform, PlayerActor playerActor, WeaponScript weapon, AreaHitStep hitStep, bool showEffect = true, Color? effectColor = null,
        GauntletImpactContext context = null, GauntletEnergyPolicy policy = null, int impactIndex = 0)
        => ApplyHitStep(ownerTransform.localToWorldMatrix, ownerTransform.rotation, playerActor, weapon, hitStep,
            showEffect, effectColor, context, policy, impactIndex);

    internal static int ApplyHitStep(Matrix4x4 ownerMatrix, Quaternion ownerRotation, PlayerActor playerActor,
        WeaponScript weapon, AreaHitStep hitStep, bool showEffect, Color? effectColor,
        GauntletImpactContext context, GauntletEnergyPolicy policy, int impactIndex)
    {
        Vector3 forward = ownerRotation * Vector3.forward;
        float range = hitStep.rangeOverride > 0f
            ? hitStep.rangeOverride
            : weapon != null && weapon.attackDistance > 0f
                ? weapon.attackDistance
                : 2f;

        Vector3 boxSize = hitStep.boxSize != Vector3.zero
            ? hitStep.boxSize
            : weapon != null
                ? weapon.attackBoxSize
                : Vector3.zero;

        float weaponDamage = weapon != null ? weapon.attackDamage : 0f;
        Vector3 origin = ownerMatrix.MultiplyPoint3x4(hitStep.localOffset);
        HitReactionRequest reactionRequest = new HitReactionRequest(
            playerActor,
            origin + forward * Mathf.Max(0f, range),
            forward,
            hitStep.reactionType,
            hitStep.hitStrength,
            hitStep.stanceDamage,
            hitStep.breakEffect,
            hitStep.pushDistance,
            hitStep.stunDuration,
            hitStep.knockUpHeight,
            hitStep.knockbackDistance);

        if (context != null && policy != null)
            return playerActor.TryApplyGauntletAreaDamage(origin, forward, range, boxSize,
                hitStep.hitShape, hitStep.sphereRadius, hitStep.targetLayers, weaponDamage, hitStep.damageMultiplier,
                hitStep.bonusDamage, reactionRequest, showEffect, effectColor, context, policy, impactIndex);

        return playerActor.TryApplyAreaDamage(
            origin,
            forward,
            range,
            boxSize,
            hitStep.hitShape,
            hitStep.sphereRadius,
            hitStep.targetLayers,
            weaponDamage,
            hitStep.damageMultiplier,
            hitStep.bonusDamage,
            reactionRequest, showEffect, effectColor);
    }

    internal static void FaceMousePosition(Transform actorTransform)
    {
        Camera camera = Camera.main;
        if (camera == null) return;

        Ray ray = camera.ScreenPointToRay(GetMousePosition());
        Plane groundPlane = new Plane(Vector3.up, actorTransform.position);
        if (!groundPlane.Raycast(ray, out float distance)) return;

        Vector3 targetPoint = ray.GetPoint(distance);
        Vector3 direction = targetPoint - actorTransform.position;
        direction.y = 0f;

        if (direction.sqrMagnitude > Mathf.Epsilon)
        {
            actorTransform.rotation = Quaternion.LookRotation(direction);
        }
    }

    private static Vector3 GetMousePosition()
    {
#if ENABLE_INPUT_SYSTEM
        if (Mouse.current != null)
        {
            return Mouse.current.position.ReadValue();
        }
#endif
        return Input.mousePosition;
    }
}
