using UnityEngine;

/// <summary>Short scaled-time visual collapse. Encounter teardown owns this object too.</summary>
public sealed class FirstSectorEnemyDespawn : MonoBehaviour
{
    private float _time;private Vector3 _scale;
    private void Awake(){_scale=transform.localScale;}
    private void Update()
    {
        if(Time.timeScale<=0||Time.deltaTime<=0)return;
        _time+=Time.deltaTime;float t=Mathf.Clamp01(_time/.28f);
        transform.localScale=Vector3.Scale(_scale,new Vector3(1-t*.24f,1-t*.93f,1-t*.24f));
        if(t>=1)Destroy(gameObject);
    }
}
