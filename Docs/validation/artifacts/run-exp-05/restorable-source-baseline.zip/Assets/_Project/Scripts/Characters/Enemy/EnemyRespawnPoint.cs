using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyRespawnPoint : MonoBehaviour
{
    [Header("Spawn")]
    [SerializeField] private GameObject enemyPrefab;
    [SerializeField] private Actor initialEnemy;
    [SerializeField] private bool spawnOnStart = true;
    [SerializeField] private int spawnCount = 1;
    [SerializeField] private float spawnRadius = 0f;
    [SerializeField] private float respawnDelay = 5f;
    [SerializeField] private Transform spawnedParent;
    [SerializeField] private bool alignToNavMesh = true;
    [SerializeField] private float navMeshSearchRadius = 2f;

    [Header("Mob Defaults")]
    [Tooltip("Optional rarity and abilities; applied on every spawn, including the initial enemy.")]
    [SerializeField] private EnemyProfile _enemyProfile;
    [SerializeField] private bool configureRankOnSpawn = true;
    [SerializeField] private bool addCombatReactionIfMissing = true;
    [SerializeField] private EnemyRank enemyRank = EnemyRank.Normal;
    [SerializeField] private bool allowBossAirJuggle;
    [SerializeField] private bool allowBossRagdoll;

    private readonly List<Actor> activeEnemies = new List<Actor>();

    // Feature: procedural-stage-room-generation (task 8.4). When true, a spawned enemy's death is
    // NOT auto-respawned: the ProgressionDirector owns the room's alive-count / clear lifecycle
    // (R3.5, R6.1) and re-populating the room would prevent it from ever reaching zero. Additive
    // and opt-in — the legacy FirstSector authored respawn behavior is unchanged when left false.
    private bool _respawnSuppressed;

    /// <summary>
    /// Injects the enemy prefab this point spawns and stops it from spawning on <c>Start</c>, so a
    /// runtime-created spawn point (with no serialized prefab) can be driven programmatically by the
    /// <c>ProgressionDirector</c>/<c>RoomCompositionResolver</c>. Also suppresses death-triggered
    /// respawns so the owning director can track a room's alive count to zero (R3.5/R6.1). Purely
    /// additive: existing serialized/authored spawn points are unaffected.
    /// </summary>
    /// <remarks>Feature: procedural-stage-room-generation. Requirements: 3.5, 5.4, 6.1.</remarks>
    /// <param name="prefab">The enemy prefab to instantiate on each <see cref="SpawnEnemy"/>.</param>
    public void ConfigurePrefab(GameObject prefab, Transform parent = null)
    {
        enemyPrefab = prefab;
        if (parent) spawnedParent = parent;
        spawnOnStart = false;
        _respawnSuppressed = true;
    }

    private void Start()
    {
        if (initialEnemy)
        {
            RegisterEnemy(initialEnemy);
            ConfigureSpawnedEnemy(initialEnemy.gameObject);
        }

        if (spawnOnStart)
        {
            SpawnMissingEnemies();
        }
    }

    public void SpawnMissingEnemies()
    {
        int enemiesToSpawn = Mathf.Max(1, spawnCount) - activeEnemies.Count;
        for (int i = 0; i < enemiesToSpawn; i++)
        {
            SpawnEnemy();
        }
    }

    public Actor SpawnEnemy()
    {
        if (!enemyPrefab)
        {
            Debug.LogWarning($"{nameof(EnemyRespawnPoint)} requires an enemy prefab to spawn.", this);
            return null;
        }

        Vector3 position = ResolveSpawnPosition();
        Quaternion rotation = transform.rotation;
        Transform parent = spawnedParent ? spawnedParent : null;
        GameObject enemyInstance = Instantiate(enemyPrefab, position, rotation, parent);

        if (enemyInstance.TryGetComponent(out NavMeshAgent agent) && agent.enabled)
        {
            agent.Warp(position);
        }

        Actor actor = enemyInstance.GetComponent<Actor>();
        if (!actor)
        {
            actor = enemyInstance.GetComponentInChildren<Actor>();
        }

        if (!actor)
        {
            Debug.LogWarning($"{nameof(EnemyRespawnPoint)} spawned an enemy without an Actor component.", enemyInstance);
            return null;
        }

        RegisterEnemy(actor);
        ConfigureSpawnedEnemy(enemyInstance);
        return actor;
    }

    private void RegisterEnemy(Actor enemy)
    {
        if (!enemy || activeEnemies.Contains(enemy)) return;

        activeEnemies.Add(enemy);
        enemy.Died += OnEnemyDied;
    }

    private void ConfigureSpawnedEnemy(GameObject enemyObject)
    {
        // Set the rank first so the reaction controller exists and knows its category; the
        // EnemyVariant then layers the profile's stance pool and CC resistances on top.
        if (configureRankOnSpawn && enemyObject)
        {
            CombatReactionController reactionController = enemyObject.GetComponentInChildren<CombatReactionController>();
            if (!reactionController && addCombatReactionIfMissing)
            {
                reactionController = enemyObject.AddComponent<CombatReactionController>();
            }
            if (reactionController)
            {
                reactionController.ConfigureRank(enemyRank, allowBossAirJuggle, allowBossRagdoll);
            }
        }

        if (enemyObject && _enemyProfile)
        {
            EnemyAI ai = enemyObject.GetComponentInChildren<EnemyAI>();
            if (ai && ai.GetComponent<Actor>())
            {
                EnemyVariant variant = ai.GetComponent<EnemyVariant>();
                if (!variant) variant = ai.gameObject.AddComponent<EnemyVariant>();
                variant.Configure(_enemyProfile);
            }
            else Debug.LogWarning("Enemy profile requires Actor and EnemyAI on the same object.", enemyObject);
        }
    }

    private void OnEnemyDied(Actor enemy)
    {
        enemy.Died -= OnEnemyDied;
        activeEnemies.Remove(enemy);

        // When driven by the ProgressionDirector the room's clear lifecycle owns respawns, so a
        // death must not silently re-populate the room (R3.5/R6.1).
        if (_respawnSuppressed) return;

        StartCoroutine(RespawnAfterDelay());
    }

    private IEnumerator RespawnAfterDelay()
    {
        yield return new WaitForSeconds(Mathf.Max(0f, respawnDelay));
        SpawnEnemy();
    }

    private Vector3 ResolveSpawnPosition()
    {
        Vector3 position = transform.position + Random.insideUnitSphere * Mathf.Max(0f, spawnRadius);
        position.y = transform.position.y;
        if (!alignToNavMesh) return position;

        if (NavMesh.SamplePosition(position, out NavMeshHit hit, Mathf.Max(0.1f, navMeshSearchRadius), NavMesh.AllAreas))
        {
            return hit.position;
        }

        return position;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, 0.35f);
        Gizmos.DrawLine(transform.position, transform.position + transform.forward);
    }

    private void OnValidate()
    {
        spawnCount = Mathf.Max(1, spawnCount);
        spawnRadius = Mathf.Max(0f, spawnRadius);
        respawnDelay = Mathf.Max(0f, respawnDelay);
        navMeshSearchRadius = Mathf.Max(0.1f, navMeshSearchRadius);
    }
}
