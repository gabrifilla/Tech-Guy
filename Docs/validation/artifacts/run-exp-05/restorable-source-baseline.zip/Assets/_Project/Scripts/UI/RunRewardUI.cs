using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>Transient reward cards and a build inspection page owned by the player pause menu.</summary>
public sealed class RunRewardUI : MonoBehaviour
{
    private RunBoons _run;
    private PauseMenuUI _pause;
    private Vector2 _buildScroll;
    private float _buildCardWidth = -1f;
    private string[] _buildDescriptions = Array.Empty<string>();
    private string[] _buildCategoryHeaders = Array.Empty<string>();
    private float[] _buildTitleHeights = Array.Empty<float>();
    private float[] _buildCardHeights = Array.Empty<float>();
    [NonSerialized] private GUIStyle _heading, _title, _body, _small, _badge, _symbol;
    private int _selected, _knownRoom = -1, _knownCount = -1;
    private readonly List<RunBoons.Offer> _owned = new List<RunBoons.Offer>();
    private readonly Dictionary<string, RunModifierPresentation> _presentation = new Dictionary<string, RunModifierPresentation>();
    private Vector2 _lastPointer;

    // Dirty-tracking (R2.3/R2.6): IMGUI rebuilds the same reward strings every frame. Reuse the shared
    // pure dirty-tracker (UiValueCache, task 7.1) to rebuild them only when the underlying reward data
    // changes. The drawn layout/rects are untouched; only the string construction moves behind these
    // dirty gates, so the visuals stay identical.
    // Choices-screen gate, keyed by (RewardRoom, Acquired.Count, choices count). Choices only change on
    // OfferReward, which also bumps RewardRoom, so this triple fully captures when a rebuild is needed.
    private readonly UiValueCache<(int room, int acquired, int choices, int revision)> _choiceGate = new UiValueCache<(int, int, int, int)>();
    private string _roomHeader = "";
    private string _acquiredFooter = "";
    private string[] _cardLevels = System.Array.Empty<string>();
    private string[] _cardHints = System.Array.Empty<string>();
    private string[] _cardActions = System.Array.Empty<string>();
    // Build-screen caches, keyed by Acquired.Count (the only thing that changes the owned list, ranks
    // and header). Rebuilt alongside the owned-list rebuild that already gates on _knownCount.
    private string _buildHeader = "";
    private string _comboHints = "";
    private string[] _tileLevels = System.Array.Empty<string>();
    private static readonly Color Ink = new Color(.035f,.045f,.065f,.98f);
    private static readonly Color Muted = new Color(.6f,.67f,.75f);
    public bool IsBuildVisible => _run && _pause && _pause.IsUpgradesVisible;
    public bool IsRewardSelectionVisible => _run && _run.IsChoosing && Time.timeScale > 0f && (!_pause || !_pause.BlocksInput);

    public void Bind(RunBoons run)
    {
        _run = run;
        _pause = run ? run.GetComponent<PauseMenuUI>() : null;
        if (_pause) _pause.BindRewards(this);
        _knownCount = _knownRoom = -1;
        _selected = 0;
        _buildScroll = Vector2.zero;
        _presentation.Clear();
        _choiceGate.Invalidate();
    }

    private void OnEnable()
    {
        _heading = _title = _body = _small = _badge = _symbol = null;
        _knownCount = -1;
        _choiceGate.Invalidate();
    }
    public float BuildTop { get; set; } = 96f;

    private void Update()
    {
        if (!IsRewardSelectionVisible) return;
        if (_knownRoom != _run.RewardRoom) { _knownRoom = _run.RewardRoom; _selected = 0; }
        var keyboard = Keyboard.current;
        if (keyboard == null) return;
        if (keyboard.digit1Key.wasPressedThisFrame) _run.Choose(0);
        else if (keyboard.digit2Key.wasPressedThisFrame) _run.Choose(1);
        else if (keyboard.digit3Key.wasPressedThisFrame) _run.Choose(2);
        else if (keyboard.leftArrowKey.wasPressedThisFrame) _selected = Mathf.Max(0, _selected - 1);
        else if (keyboard.rightArrowKey.wasPressedThisFrame) _selected = Mathf.Min(_run.Choices.Count - 1, _selected + 1);
        else if (keyboard.enterKey.wasPressedThisFrame) _run.Choose(_selected);
    }
    private RunModifierPresentation Present(RunBoons.Offer offer)
    {
        if (!_presentation.TryGetValue(offer.Id, out var view) || ProtocolInventory.TryKind(offer.Id, out _) && view.Description != offer.Description)
            _presentation[offer.Id] = view = RunModifierPresentation.For(offer);
        return view;
    }
    private static GUIStyle Style(int size, FontStyle weight)
    {
        var style = new GUIStyle(GUI.skin.label) { fontSize = size, fontStyle = weight, wordWrap = true, richText = true, padding = new RectOffset(0,0,0,0) };
        style.normal.textColor = new Color(.92f,.94f,.97f); return style;
    }
    private void Styles()
    {
        if (_heading != null && _title != null && _body != null && _small != null && _badge != null && _symbol != null) return;
        _heading = Style(34, FontStyle.Bold); _title = Style(23, FontStyle.Bold);
        _body = Style(17, FontStyle.Normal); _small = Style(12, FontStyle.Normal);
        _badge = Style(12, FontStyle.Bold); _badge.alignment = TextAnchor.MiddleCenter;
        _symbol = Style(28, FontStyle.Bold); _symbol.alignment = TextAnchor.MiddleCenter;
    }
    private static void Fill(Rect rect, Color color)
    { Color old = GUI.color; GUI.color = color; GUI.DrawTexture(rect, Texture2D.whiteTexture); GUI.color = old; }
    private static void Text(Rect rect, string text, GUIStyle style, Color color)
    { Color old = style.normal.textColor; style.normal.textColor = color; GUI.Label(rect,text,style); style.normal.textColor = old; }
    private void Description(Rect rect, string value)
    {
        string text = RunModifierPresentation.Emphasize(value);
        int originalSize = _body.fontSize;
        while (_body.fontSize > 14 && _body.CalcHeight(new GUIContent(text), rect.width) > rect.height) _body.fontSize--;
        GUI.Label(rect, text, _body);
        _body.fontSize = originalSize;
    }
    private void OnGUI()
    {
        if (!IsRewardSelectionVisible) return;
        Styles();
        Matrix4x4 previous = GUI.matrix;
        Color oldColor = GUI.color;
        float scale = Mathf.Max(.1f, Mathf.Min(Screen.width / 1280f, Screen.height / 720f));
        GUI.matrix = Matrix4x4.Scale(Vector3.one * scale);
        float width = Screen.width / scale, height = Screen.height / scale;
        try
        {
            DrawChoices(width, height);
        }
        finally { GUI.matrix = previous; GUI.color = oldColor; }
    }
    // Rebuilds the choices-screen string cache only when the reward data changes (R2.3): the room
    // header, the acquired-count footer, and the per-card level/hint/action strings + rank. These
    // depend solely on RewardRoom, the current choice set and Acquired.Count — none of which change
    // between frames while a choice screen is open. Produces the exact same strings as before (R2.6).
    private void RebuildChoiceCache()
    {
        int count = _run.Choices.Count;
        _roomHeader = "RECOMPENSA DE SALA  /  " + _run.RewardRoom.ToString("00");
        if (_run.ManualTicket != null)
        {
            _roomHeader += " · " + _run.ManualTicket.AnnouncedKind + (_run.ManualTicket.IsAlternative ? " · CATEGORIA ESGOTADA: ALTERNATIVA" : "");
            var request = _run.ManualTicket.Request;
            var node = _run.ProtocolSession.Route.Node(request.NodeId);
            _roomHeader += " · escolha " + (request.Ordinal + 1) + "/" + node.TotalAcquisitions;
            if (_run.ManualTicket.AnnouncedKind == RunRewardKind.Protocol)
                _roomHeader += " · Protocol #" + (_run.ProtocolSession.ProtocolAcquisitions + 1);
        }
        _acquiredFooter = _run.Acquired.Count + " modificadores adquiridos nesta run";
        if (_cardLevels.Length != count)
        {
            _cardLevels = new string[count];
            _cardHints = new string[count];
            _cardActions = new string[count];
        }
        for (int i = 0; i < count; i++)
        {
            var offer = _run.Choices[i];
            var view = Present(offer);
            int rank = RunModifierPresentation.Count(_run, offer.Id);
            _cardLevels[i] = offer.Id == RunBoonOfferCatalog.ExhaustedId ? "SEM AQUISIÇÃO" : view.MaxRank == 1 ? "ÚNICO" : "NÍVEL " + (rank + 1) + (view.MaxRank > 0 ? "/" + view.MaxRank : "");
            _cardHints[i] = RunModifierPresentation.Hint(_run, offer.Id);
            _cardActions[i] = "[" + (i + 1) + "]   " + (offer.Id == RunBoonOfferCatalog.ExhaustedId ? "CONTINUAR" : rank > 0 ? "MELHORAR" : "ADQUIRIR");
        }
    }
    private void DrawChoices(float width, float height)
    {
        if (_choiceGate.HasChanged((_run.RewardRoom, _run.Acquired.Count, _run.Choices.Count, _run.ManualTicket?.Revision ?? 0)))
            RebuildChoiceCache();
        Fill(new Rect(0,0,width,height), new Color(.012f,.018f,.03f,.97f));
        float left = (width - 1100) * .5f, top = (height - 650) * .5f;
        Text(new Rect(left,top+4,700,22), _roomHeader, _small, new Color(.9f,.73f,.43f));
        GUI.Label(new Rect(left,top+33,1000,50), "Escolha sua próxima evolução", _heading);
        Text(new Rect(left,top+91,1000,28), "Uma escolha. Novas combinações. Os efeitos duram até o fim desta run.", _body, Muted);
        bool pointerMoved = Event.current.mousePosition != _lastPointer;
        if (Event.current.type == EventType.Repaint) _lastPointer = Event.current.mousePosition;
        for (int i = 0; i < _run.Choices.Count; i++)
        {
            var rect = new Rect(left + i * 374, top + 145, 352, 450);
            if (rect.Contains(Event.current.mousePosition) && pointerMoved) _selected = i;
            if (DrawCard(rect, _run.Choices[i], i)) { _run.Choose(i); break; }
        }
        Text(new Rect(left,top+610,1100,24), "[1] [2] [3] escolher     •     ← → navegar + Enter     •     ou clique no cartão", _body, Muted);
        Text(new Rect(left,top+646,1100,20), _acquiredFooter, _small, Muted);
        if (_run.ManualTicket != null && GUI.Button(new Rect(left+800,top+33,290,40),"Fechar · manter pendente")) _run.CloseManualReward();
        if (_run.ManualRecoveryRequired)
            Text(new Rect(left,top+150,1000,90),"Mutation indisponível: slots incompatíveis ou ocupados. Boss continua bloqueado. Abra a pausa [Esc] e escolha Abandonar incursão para retornar ao Nexus.",_body,Muted);
    }
    private bool DrawCard(Rect rect, RunBoons.Offer offer, int index)
    {
        var view = Present(offer);
        bool active = index == _selected;
        Fill(new Rect(rect.x+4,rect.y+7,rect.width,rect.height), new Color(0,0,0,.5f));
        Fill(rect, active ? view.Accent : new Color(.18f,.23f,.3f));
        Fill(new Rect(rect.x+2,rect.y+2,rect.width-4,rect.height-4), active ? new Color(.065f,.085f,.12f) : Ink);
        Fill(new Rect(rect.x+2,rect.y+2,rect.width-4,4), view.Accent);
        float x = rect.x + 24, y = rect.y + 24, w = rect.width - 48;
        Text(new Rect(x,y,w-80,20), view.Category, _small, view.Accent);
        Text(new Rect(x+w-90,y,90,20), _cardLevels[index], _badge, view.Accent);
        Fill(new Rect(x,y+35,60,60), new Color(view.Accent.r,view.Accent.g,view.Accent.b,.12f));
        Text(new Rect(x,y+35,60,60), view.Symbol, _symbol, view.Accent);
        Text(new Rect(x+76,y+38,w-76,20), "AFETA", _small, Muted);
        Text(new Rect(x+76,y+61,w-76,30), view.Scope, _body, view.Accent);
        GUI.Label(new Rect(x,y+103,w,45), offer.Title, _title);
        Fill(new Rect(x,y+152,w,1), new Color(.2f,.26f,.34f));
        Description(new Rect(x,y+165,w,145), view.Description);
        Text(new Rect(x,y+318,w,40), _cardHints[index], _small, Muted);
        Fill(new Rect(x,rect.yMax-54,w,32), active ? view.Accent : new Color(.12f,.16f,.22f));
        Text(new Rect(x,rect.yMax-54,w,32), _cardActions[index], _badge, active ? Ink : Color.white);
        return GUI.Button(rect, GUIContent.none, GUIStyle.none);
    }
    private void RebuildBuildCache(float cardWidth)
    {
        bool inventoryChanged = _knownCount != _run.Acquired.Count;
        if (inventoryChanged)
        {
            _owned.Clear();
            var seen = new HashSet<string>();
            foreach (var offer in _run.Acquired)
                if (seen.Add(offer.Id))
                    _owned.Add(_run.Protocols != null && ProtocolInventory.TryKind(offer.Id, out var protocol)
                        ? ProtocolOfferPresentation.Create(_run.Protocols, protocol, true) : offer);
            _knownCount = _run.Acquired.Count;
            _buildHeader = _owned.Count + " upgrades diferentes  ·  " + _run.Acquired.Count + " aquisições nesta incursão";
            _comboHints = string.Join("\n", BoonExpansionCatalog.ComboHints(_run.WeaponModifiers));
            if (_tileLevels.Length != _owned.Count || _buildDescriptions.Length != _owned.Count ||
                _buildCategoryHeaders.Length != _owned.Count || _buildTitleHeights.Length != _owned.Count || _buildCardHeights.Length != _owned.Count)
            {
                _tileLevels = new string[_owned.Count];
                _buildDescriptions = new string[_owned.Count];
                _buildCategoryHeaders = new string[_owned.Count];
                _buildTitleHeights = new float[_owned.Count];
                _buildCardHeights = new float[_owned.Count];
            }
            for (int i = 0; i < _owned.Count; i++)
            {
                var view = Present(_owned[i]);
                int rank = RunModifierPresentation.Count(_run, _owned[i].Id);
                _tileLevels[i] = view.MaxRank == 1 ? "ÚNICO" : "NÍVEL " + rank + (view.MaxRank > 0 ? "/" + view.MaxRank : "");
                _buildDescriptions[i] = RunModifierPresentation.Emphasize(view.Description ?? "");
                _buildCategoryHeaders[i] = view.Category + "  /  " + view.Scope;
            }
        }
        if (!inventoryChanged && Mathf.Approximately(_buildCardWidth, cardWidth)) return;
        _buildCardWidth = cardWidth;
        for (int i = 0; i < _owned.Count; i++)
        {
            float titleHeight = Mathf.Max(30f, _title.CalcHeight(new GUIContent(_owned[i].Title), cardWidth - 110f));
            float bodyHeight = _body.CalcHeight(new GUIContent(_buildDescriptions[i]), cardWidth - 40f);
            _buildTitleHeights[i] = titleHeight;
            _buildCardHeights[i] = Mathf.Max(150f, 90f + titleHeight + bodyHeight);
        }
    }

    /// <summary>Read-only acquired upgrades. Uses the pause menu's virtual canvas and remains hidden during play.</summary>
    public void DrawPauseBuild(Rect area)
    {
        if (!IsBuildVisible) return;
        Styles();
        Color color = GUI.color, contentColor = GUI.contentColor, backgroundColor = GUI.backgroundColor;
        bool enabled = GUI.enabled;
        try
        {
            GUI.color = GUI.contentColor = Color.white;
            float cardWidth = Mathf.Max(100f, (area.width - 36f) * .5f);
            RebuildBuildCache(cardWidth);
            Text(new Rect(area.x, area.y, area.width, 28), _buildHeader, _body, Muted);
            if (_owned.Count == 0)
            {
                Fill(new Rect(area.x, area.y + 54, area.width, 180), Ink);
                GUI.Label(new Rect(area.x + 26, area.y + 80, area.width - 52, 40), "Sua build começa na próxima recompensa", _title);
                Text(new Rect(area.x + 26, area.y + 134, area.width - 52, 72),
                    "Os upgrades que você escolher aparecerão aqui, com seus níveis e efeitos. Eles duram até o fim da incursão.", _body, Muted);
                return;
            }
            float contentHeight = 0f;
            for (int i = 0; i < _owned.Count; i += 2)
                contentHeight += Mathf.Max(_buildCardHeights[i], i + 1 < _owned.Count ? _buildCardHeights[i + 1] : 0f) + 16f;
            float comboHeight = string.IsNullOrEmpty(_comboHints) ? 0f : _small.CalcHeight(new GUIContent("COMBINAÇÕES POSSÍVEIS\n" + _comboHints), area.width - 44f) + 24f;
            contentHeight += comboHeight;
            var viewport = new Rect(area.x, area.y + 44f, area.width, area.height - 44f);
            _buildScroll = GUI.BeginScrollView(viewport, _buildScroll,
                new Rect(0, 0, area.width - 20f, contentHeight), false, false);
            try
            {
                float rowTop = 0f;
                for (int i = 0; i < _owned.Count; i += 2)
                {
                    float rowHeight = Mathf.Max(_buildCardHeights[i], i + 1 < _owned.Count ? _buildCardHeights[i + 1] : 0f);
                    DrawOwnedCard(new Rect(0, rowTop, cardWidth, rowHeight), i);
                    if (i + 1 < _owned.Count) DrawOwnedCard(new Rect(cardWidth + 16f, rowTop, cardWidth, rowHeight), i + 1);
                    rowTop += rowHeight + 16f;
                }
                if (comboHeight > 0f)
                    Text(new Rect(12f, rowTop + 8f, area.width - 44f, comboHeight - 16f), "COMBINAÇÕES POSSÍVEIS\n" + _comboHints, _small, Muted);
            }
            finally { GUI.EndScrollView(); }
        }
        finally
        {
            GUI.color = color;
            GUI.contentColor = contentColor;
            GUI.backgroundColor = backgroundColor;
            GUI.enabled = enabled;
        }
    }

    private void DrawOwnedCard(Rect rect, int index)
    {
        var offer = _owned[index];
        var view = Present(offer);
        Fill(rect, Ink);
        Fill(new Rect(rect.x, rect.y, 3f, rect.height), view.Accent);
        Text(new Rect(rect.x + 20f, rect.y + 16f, rect.width - 146f, 20f), _buildCategoryHeaders[index], _small, view.Accent);
        Text(new Rect(rect.xMax - 122f, rect.y + 16f, 102f, 20f), _tileLevels[index], _badge, view.Accent);
        Fill(new Rect(rect.x + 20f, rect.y + 46f, 50f, 50f), new Color(view.Accent.r, view.Accent.g, view.Accent.b, .12f));
        Text(new Rect(rect.x + 20f, rect.y + 46f, 50f, 50f), view.Symbol, _symbol, view.Accent);
        float titleHeight = _buildTitleHeights[index];
        GUI.Label(new Rect(rect.x + 88f, rect.y + 46f, rect.width - 110f, titleHeight), offer.Title, _title);
        GUI.Label(new Rect(rect.x + 20f, rect.y + 66f + titleHeight, rect.width - 40f,
            rect.height - 82f - titleHeight), _buildDescriptions[index], _body);
    }
}
